-- MySQL dump 10.15  Distrib 10.0.20-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u484679595_try
-- ------------------------------------------------------
-- Server version	10.0.20-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `entry`
--

DROP TABLE IF EXISTS `entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entry` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `age` int(3) NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `number` int(13) unsigned DEFAULT NULL,
  `address` varchar(300) NOT NULL,
  `cb1` tinyint(1) NOT NULL,
  `cb2` tinyint(4) NOT NULL,
  `cb3` tinyint(4) NOT NULL,
  `cb4` tinyint(4) NOT NULL,
  `cb5` tinyint(4) NOT NULL,
  `cb6` tinyint(4) NOT NULL,
  `cb7` tinyint(4) NOT NULL,
  `cb8` tinyint(4) NOT NULL,
  `cb9` tinyint(4) NOT NULL,
  `cb10` tinyint(4) NOT NULL,
  `cb11` tinyint(4) NOT NULL,
  `cb12` tinyint(4) NOT NULL,
  `cb13` tinyint(4) NOT NULL,
  `cb14` tinyint(4) NOT NULL,
  `cb15` tinyint(4) NOT NULL,
  `cb16` tinyint(4) NOT NULL,
  `cb17` tinyint(4) NOT NULL,
  `cb18` tinyint(4) NOT NULL,
  `cb19` tinyint(4) NOT NULL,
  `cb20` tinyint(4) NOT NULL,
  `cb21` tinyint(4) NOT NULL,
  `cb22` tinyint(4) NOT NULL,
  `cb23` tinyint(4) NOT NULL,
  `cb24` tinyint(4) NOT NULL,
  `cb25` tinyint(4) NOT NULL,
  `cb26` tinyint(4) NOT NULL,
  `cb27` tinyint(4) NOT NULL,
  `cb28` tinyint(4) NOT NULL,
  `cb29` tinyint(4) NOT NULL,
  `cb30` tinyint(4) NOT NULL,
  `cb31` tinyint(4) NOT NULL,
  `r1` tinyint(4) NOT NULL,
  `r2` tinyint(4) NOT NULL,
  `r3` tinyint(4) NOT NULL,
  `r4` tinyint(4) NOT NULL,
  `r5` tinyint(4) NOT NULL,
  `r6` tinyint(4) NOT NULL,
  `r7` tinyint(4) NOT NULL,
  `r8` tinyint(4) NOT NULL,
  `r9` tinyint(4) NOT NULL,
  `r10` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entry`
--

/*!40000 ALTER TABLE `entry` DISABLE KEYS */;
INSERT INTO `entry` VALUES (59,'rohit','dsj@jdjd.cc',43,0,2321332121,'fsdlkfjklasfjk',1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(58,'rohit','rohitguptafe@gmail.coma',44,0,343242424,'bvf',1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(57,'hello from mob','gug@fgn.b',80,0,4294967295,'Hgbjj',1,1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,1,0,1,1,1,1,0,0,0,0,0,0,0,0,1,3,3,3,2,4,2,1,2,3,2),(56,'Rohit','rohitguptafe@gmail.com',0,0,4294967295,'g-192\r\nsv',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `entry` ENABLE KEYS */;

--
-- Table structure for table `task_list`
--

DROP TABLE IF EXISTS `task_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_list` (
  `task_id` int(4) NOT NULL AUTO_INCREMENT,
  `id` int(4) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `assi_time` timestamp NULL DEFAULT NULL,
  `comp_time` timestamp NULL DEFAULT NULL,
  `task_name` varchar(200) NOT NULL,
  PRIMARY KEY (`task_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_list`
--

/*!40000 ALTER TABLE `task_list` DISABLE KEYS */;
INSERT INTO `task_list` VALUES (1,1,-1,NULL,NULL,'do all'),(2,1,-1,NULL,NULL,'try kit'),(3,2,0,NULL,NULL,'yop'),(4,1,0,NULL,NULL,'yo'),(5,1,-1,NULL,NULL,'see work'),(6,0,0,NULL,NULL,'come on time'),(7,2,0,NULL,NULL,'trykit'),(8,1,1,NULL,NULL,'employee manage'),(9,3,1,NULL,NULL,'check'),(10,4,0,NULL,NULL,'ss'),(11,4,0,NULL,NULL,'ss'),(12,4,0,NULL,NULL,'asa'),(13,4,0,NULL,NULL,'aaa'),(14,2,0,NULL,NULL,'as'),(15,1,0,NULL,NULL,'wewqewq'),(16,11,0,NULL,NULL,'a'),(17,1,0,NULL,NULL,'nice job\r\n');
/*!40000 ALTER TABLE `task_list` ENABLE KEYS */;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team` (
  `team_id` int(4) NOT NULL,
  `u_id` int(4) NOT NULL,
  `pos_team` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`team_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

/*!40000 ALTER TABLE `team` DISABLE KEYS */;
/*!40000 ALTER TABLE `team` ENABLE KEYS */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `email` varchar(30) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) DEFAULT NULL,
  `gender` tinyint(1) NOT NULL,
  `dob` text,
  `address` varchar(200) DEFAULT NULL,
  `mphone` bigint(10) NOT NULL,
  `emphone` bigint(10) DEFAULT NULL,
  `intern_time` int(2) DEFAULT NULL,
  `join_date` text,
  `work_field` varchar(20) DEFAULT NULL,
  `work_pos` varchar(20) DEFAULT NULL,
  `salary` int(10) DEFAULT NULL,
  `team_id` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'krishna','krish',0,'krishnav708@gmail.com','krishna','varshney',0,'0000-00-00',NULL,7878787878,NULL,1,'2015-06-05',NULL,NULL,NULL,NULL),(1,'rohit','2d235ace000a3ad85f590e321c89bb99',0,'rohitguptafe@gmail.com','rohit','gupta',0,'1995-10-10','g-192, sv, nd-80',9958853253,9958652106,1,'2015-06-05','tech',NULL,NULL,NULL),(4,'admin','21232f297a57a5a743894a0e4a801fc3',0,'','',NULL,0,'0000-00-00',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,'amit','0cb1eb413b8f7cee17701a37a1d74dc3',1,'amitgupta@gmail.com','amit','gupta',0,'0000-00-00','sadalsd,gasdf-33123904-sada1892183',9999999999,100,11,'0000-00-00','Sales','Project manager',100000,2),(9,'test','test',0,'test','test','test',0,'0000-00-00','r32424',8729789,2342134,11,'0000-00-00','Designing','Senoir Engg',100000,2),(10,'rohitgupta','rohit',0,'rohitgupta','rohitgupta','rohitgupta',0,'0000-00-00','rohitgupta',55,121,11,'0000-00-00','Sales','Head',2,2),(11,'111','111',0,'111','111','111',0,'0000-00-00','g-192\r\nsv',111,9958652106,10,'0000-00-00','Tech','Senoir Engg',111,1),(12,'1111','1111',0,'111','111','111',0,'0000-00-00','g-192\r\nsv',111,9958652106,10,'0000-00-00','Tech','Senoir Engg',111,1),(13,'11111','111111',0,'111','111','111',0,'0000-00-00','g-192\r\nsv',111,9958652106,10,'0000-00-00','Tech','Senoir Engg',111,1),(14,'111111','11111',0,'111','111','111',0,'0000-00-00','g-192\r\nsv',111,9958652106,10,'0000-00-00','Tech','Senoir Engg',111,1),(15,'vv','vv',0,'a','a','a',0,'0000-00-00','vv',0,22,1,'0000-00-00','Designing','Head',33,1),(16,'vv1','111',0,'a','a','a',0,'05/22/0001','vv',0,22,1,'06/09/2015','Designing','Head',33,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-18  7:31:26
